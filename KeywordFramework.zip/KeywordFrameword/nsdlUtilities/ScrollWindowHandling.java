package nsdlUtilities;

import org.openqa.selenium.JavascriptExecutor;

import nsdlKeyword.NSDLUtils;

public class ScrollWindowHandling extends NSDLUtils {

	
	public static void scrollHandling() 
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scrollBy(0,600)");
	}
	
}
