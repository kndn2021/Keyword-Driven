package nsdlUtilities;

import org.openqa.selenium.Alert;

import nsdlKeyword.NSDLUtils;

public class AlertWindowHandling extends NSDLUtils{

	
	public static void alertHandling() 
	{
		Alert alert = driver.switchTo().alert();
		if (inputData.equalsIgnoreCase("accept"))
		{
			alert.accept();
			System.out.println("Alert is accepted");
		} else if (inputData.equalsIgnoreCase("dismiss")) 
		{
			alert.dismiss();
			System.out.println("Alert is dismissed");
		} else
		{
			alert.sendKeys(inputData);
			System.out.println("Input taken by alert window");
		}
	}
	
}
